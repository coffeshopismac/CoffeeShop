import { TasksList } from "../components/TaskList";

export function TasksPage() {
  return <TasksList />;
}
